﻿namespace Gameplay
{
    public class Action_IFRANDOMPCT : LatentScriptedAction
    {
        public float Probability;
    }
}