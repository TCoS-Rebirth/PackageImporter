﻿namespace Gameplay
{
    public class LatentScriptedAction : ScriptedAction
    {

    }
}