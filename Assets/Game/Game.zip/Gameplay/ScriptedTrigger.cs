﻿namespace Gameplay
{
    public class ScriptedTrigger : ScriptedSequence
    {
        //SCriptedTriggerController TriggerController; 
    }
}