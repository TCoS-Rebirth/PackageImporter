namespace Gameplay
{
    public class ACTION_Untriggerevent : Action_TRIGGEREVENT
    {
    }
}