namespace Gameplay
{
    public class ScriptedTriggerController: ScriptedController
    {
        
    }
}