using Engine;

namespace Gameplay
{
    public class Drowned : DamageType
    {
        
    }
}