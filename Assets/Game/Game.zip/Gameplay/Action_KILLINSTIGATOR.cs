﻿namespace Gameplay
{
    public class Action_KILLINSTIGATOR : LatentScriptedAction
    {
        
    }
}