﻿using Engine;

namespace Gameplay
{
    public class WaterVolume : PhysicsVolume
    {
        //public float DamagePerSec;
        //public DamageType DamageType;
        //public bool bPainCausing;
        //public Color DistanceFogColor;
        //public float DistanceFogStart;
        //public float DistanceFogEnd;
    }
}