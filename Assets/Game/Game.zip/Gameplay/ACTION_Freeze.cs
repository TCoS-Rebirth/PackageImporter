namespace Gameplay
{
    public class ACTION_Freeze : LatentScriptedAction
    {
        public override string ActionString
        {
            get { return "Freeze"; }
        }
    }
}