﻿using Engine;

namespace Gameplay
{
    public class Action_IFCONDITION: LatentScriptedAction
    {
        public NameProperty TriggeredConditionTag;
    }
}
