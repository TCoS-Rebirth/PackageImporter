﻿using Engine;

namespace Gameplay
{
    public class TriggeredCondition: Triggers
    {
        public bool bTriggerControlled;
        public bool bToggled;
    }
}
