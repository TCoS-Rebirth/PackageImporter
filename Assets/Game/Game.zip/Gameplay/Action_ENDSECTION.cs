namespace Gameplay
{
    public class Action_ENDSECTION : LatentScriptedAction
    {
    }
}