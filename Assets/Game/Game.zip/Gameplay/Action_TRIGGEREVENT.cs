using Engine;

namespace Gameplay
{
    public class Action_TRIGGEREVENT : LatentScriptedAction
    {
        public NameProperty Event ="";
    }
}