namespace Gameplay
{
    public class TriggerLight : ScriptedTrigger
    {
        public float MaxCoronaSize;
    }
}