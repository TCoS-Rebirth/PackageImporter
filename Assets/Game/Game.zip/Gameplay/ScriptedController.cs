using Engine;

namespace Gameplay
{
    public class ScriptedController : AIController
    {
        
    }
}